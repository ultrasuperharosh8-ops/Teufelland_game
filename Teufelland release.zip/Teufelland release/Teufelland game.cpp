﻿#include <iostream>
#include <fstream>
#include <string>
#include <conio.h>
#include <stdlib.h>
using namespace std;

int move(char (&map)[100][100], char input, int &pos_i, int &pos_j) { //returns if the player has engaged into battle or opened menu
    int delta_i=0, delta_j=0;
    int returning = 0; //returning = 1 - battle, = 2 - opening menu, = 3 - loot, = 4 - trap, = 5 - saving alexandra cutscene, = 6 - battle with da boss
    if (input == 's' && pos_i < 8) {
        if (map[pos_i + 1][pos_j] != '#') {
            delta_i = 1;
        }

    }
    if (input == 'w' && pos_i > 0) {
        if (map[pos_i - 1][pos_j] != '#') {
            delta_i = -1;
        }
    }
    if (input == 'a' && pos_j > 0) {
        if (map[pos_i][pos_j-1] != '#') {
            delta_j = -1;
        }
    }
    if (input == 'd' && pos_j < 30) {
        if (map[pos_i][pos_j + 1] != '#') {
            delta_j = 1;
        }
    }
    if (input == 'm') {
        return 2;
    }
    if (map[pos_i + delta_i][pos_j + delta_j] == '?') {
        returning = 3;
    }
    if (map[pos_i + delta_i][pos_j + delta_j] == '!') {
        returning = 4;
    }
    if (map[pos_i + delta_i][pos_j + delta_j] == 'A') {
        returning = 5;
    }
    if (map[pos_i + delta_i][pos_j + delta_j] == 'B') {
        returning = 6;
    }
    if (map[pos_i + delta_i][pos_j + delta_j] == 'O') {
        returning = 1;
    }
    map[pos_i][pos_j] = ' ';
    map[pos_i + delta_i][pos_j + delta_j] = 'p';
    pos_i += delta_i;
    pos_j += delta_j;
    return returning;
}
void get_player_stats(string nickname, int& weapon, int& hp, int& money, int& armor, int& materials, int& level) {
    ifstream readstats(nickname + ".txt");
    readstats >> weapon >> hp >> money >> armor >> materials >> level;
    readstats.close();
}

int main()
{
    int error_code = system("python main_menu.py");
    if (error_code != 0) return 1;

    //getting player stats
    ifstream get_player_name("temp.txt");
    string nickname;
    int weapon, hp, money, armor, materials, level=1;
    get_player_name >> nickname;
    get_player_name.close();
    int p_pos_i = 4, p_pos_j = 1;

    while (level <= 3) {
        get_player_stats(nickname, weapon, hp, money, armor, materials, level);
        cout << "Legend:         Controls:\n# - walls       w,a,s,d - walk\np - you         e - exit\nO - enemy       m - menu\n";
        char map[100][100];
        string level_filename = "level" + to_string(level) + ".txt";
        ifstream map_input(level_filename);
        string map_string = "", line;
        while (getline(map_input, line)) {
            map_string += line + "\n";
        }
        cout << level_filename << endl;
        map_string += "\n";
        int count = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 32; j++) {
                map[i][j] = map_string[count];
                count++;
                if (i == p_pos_i && j == p_pos_j) {
                    map[i][j] = 'p';
                }
                cout << map[i][j];
            }
        }
        char p_input = 'w';
        while (p_input != 'e') {
            p_input = _getch();
            if (p_input == 'e') {
                return 0;
            }
            int has_engaged_into_battle = move(map, p_input, p_pos_i, p_pos_j);
            cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
            cout << "Legend:         Controls:\n# - walls       w,a,s,d - walk\np - you         e - exit\nO - enemy       m - menu\n! - trap\n? - loot\n";
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 32; j++) {
                    cout << map[i][j];
                }
            }


            //kinda looks stupid, I'm repeating here. Could have used switch case, but if it works, I'm not touching it
            if (has_engaged_into_battle == 1) {
                error_code = system("python Fight.py");
                if (error_code != 0) {
                    break;
                }
            }
            if (has_engaged_into_battle == 2) {
                error_code = system("python menu.py");
                if (error_code != 0) {
                    break;
                }
            }
            if (has_engaged_into_battle == 3) {
                error_code = system("python loot.py");
                if (error_code != 0) {
                    break;
                }
            }
            if (has_engaged_into_battle == 4) {
                error_code = system("python trap.py");
                if (error_code != 0) {
                    break;
                }
            }
            if (has_engaged_into_battle == 5) {
                error_code = system("python Alexandra.py");
                if (error_code != 0) {
                    break;
                }
            }
            if (has_engaged_into_battle == 6) {
                error_code = system("python bossfight.py");
                if (error_code != 0) {
                    break;
                }
                error_code = system("python finalCutscene.py");
                return 0;
            }


            if (p_pos_i == 4 && p_pos_j == 30) {
                cout << "Level complete! ";
                get_player_stats(nickname, weapon, hp, money, armor, materials, level);
                ofstream changeLevel(nickname + ".txt");
                changeLevel << weapon + 5 << " " << hp + 30 << " " << money + 30 << " " << armor + 5 << " " << materials + 5 << " " << level + 1;
                changeLevel.close();
                p_pos_j = 1;
                break;
            }

            if (p_pos_i == 4 && p_pos_j == 0) {
                cout << "Going backwards ";
                ofstream changeLevel(nickname + ".txt");
                changeLevel << weapon - 5 << " " << hp - 30 << " " << money - 30 << " " << armor - 5 << " " << materials - 5 << " " << level - 1;
                changeLevel.close();
                p_pos_j = 29;
                break;
            }
        }
    }
    return 0;
}