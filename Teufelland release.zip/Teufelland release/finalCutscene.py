import os
import time

def cutscene(ascii_art, msg):
    animation = ""
    for i in range(len(msg)):
            os.system('cls')
            animation += msg[i]
            print(ascii_art + "\n\n\n")
            print(animation)
            time.sleep(0.03)
    input("Press enter to continue ")

art = "               #####\n              #######\n  #####################\n#########################\n ########################\n  ######################\n        #############\n         ###      #\n        ##       ####\n       ##         #\n"
msg = "The portal is closed. Evil creatures disappeared, and Malus Inevitablis lies dead.\nThe Erlsburg is safe again, and you've completed your mission"
cutscene(art, msg)
msg = "The king and baron fulfilled their promises. You've given Teufelland"
cutscene(art, msg)
art = "      #   #   #      \n      #___#___#      \n       #     #       \n       #######       \n      # _   _ #      \n      # o   o #      \n      ## ### ##      \n       ###_###       \n         # #         \n         # #         \n"
msg = "King granted you with the status of Sir, placing a sword on your shoulders"
cutscene(art, msg)
art = "  \n  ### \n # # #\n # #  \n  ##  \n   ## \n   # #\n   # #\n #### \n   #  \n   #  \n"
msg = "You gained hundreds pounds of gold, enough for rest of your life."
cutscene(art, msg)
art = "      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # ^   ^ #   #  \n   #  #   #   #   #  \n  #    #  W  #     # \n #       # #        #\n #       # #        #\n"
msg = "and you married Alexandra. Till death do you part."
art = "            #            \n  #        ###        #  \n ###      ## ##      ### \n#####    #######    #####\n## ##    ### ###    ## ##\n## ## # #### #### # ## ##\n#########################\n#########################\n## ########   ######## ##\n## #######     ####### ##\n##########     ##########\n"
msg = "Erlsburg began to prosper. Everything went good.\nChurches built, new lands conquered, domains developed.\nUnder your rule Teufelland recovered from 40 years of occupation."
cutscene(art, msg)
art = "         #######         \n         ######:         \n  ::::   ## ::           \n ##:::   ##:::    #:     \n ####::  #####:   #:     \n #####:: #######  ##     \n#########################\n"
msg = "but beyond the Rift, there was silence. Nothing, but ruins of Malum Inevitablis's civilization.\nLands cruble to dust. Everyone is dead. No one in Erlsburg will hear their cries.\nAnd no one ever will"
cutscene(art, msg)
msg = "Because one world survived and won.\nAnd the other lost"
cutscene(art, msg)
art = "  ###   ###  \n #   # #   # \n#     #     #\n#           #\n #         # \n  #       #  \n   #     #   \n    #   #    \n     # #     \n      #      \n"
msg = "Thanks for playing!\nGame made by Magzhan Uderbay and Artemyi Poberezhnyi\nas a group project for informatics class"
cutscene(art, msg)
exit(0)