from statistics import harmonic_mean
import time
import random


#2 exit code is for losing a battle
#1 exit code is for an error
#0 is ok exit code
print("\n\n\n\n                      ###\n                     ####\n                    #### \n                   ####  \n                  ####   \n                 ####    \n                ####     \n           ##  ####      \n           ## ####       \n            #####        \n            ######       \n           #### ###      \n          ####           \n")
easy_monsters_values = [7, 12]
easy_monsters = ["goblin", "zombie"]
medium_monsters_values = [10, 18]
medium_monsters = ["lizzard", "skeleton"]
hard_monsters_values = [50, 125]
hard_monsters = ["witch", "dragon"]
player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}

#getting player's nickname
with open("temp.txt", 'r') as transit_vars:
    nickname = transit_vars.read()
print(nickname + ":")


#getting player's stats
with open(nickname + ".txt", 'r') as load_player:
    file_content = load_player.read().split()
    arr_count = 0
    for key in player:
          player[key] = int(file_content[arr_count])
          arr_count+=1
print(player)



if player["level"] == 1:
    enemy_key = random.choice(easy_monsters)
    enemy_value = random.randint(6, 12)
elif player["level"] == 2:
    enemy_key = random.choice(medium_monsters)
    enemy_value = random.randint(15, 25)
elif player["level"] == 3:
    enemy_key = random.choice(hard_monsters)
    enemy_value = random.randint(50, 125)



enemy_damage = random.randint(int(enemy_value * 0.8), int(enemy_value * 1.2))
enemy_health = enemy_value * 2
print("You are attacked by " + enemy_key)
print("With damage of " + str(enemy_damage) + " and health of " + str(enemy_health))
print("z - to fight, c - to run away")
fight_or_flight = str(input())


#fight
if fight_or_flight == "z":
    p_HP_battle = player["HP"]
    while (True):
        p_HP_battle -= enemy_damage - 0.5*player["armor"]
        print(enemy_key + " attack: " + str(enemy_damage*-1) + "\nYour health points: " + str(p_HP_battle) + "remaining.")
        time.sleep(1)
        enemy_health -= player["weapon"]
        print("your attack: " + str(player["weapon"]*-1) + "\nEnemy health points: " + str(enemy_health) + "remaining.")
        time.sleep(1)
        if p_HP_battle <= 0:
            print("You lost! Game over. ")
            exit(2)
        elif enemy_health <= 0:
            print("You won! ")
            break
    player["money"] += int(enemy_value * 2.5)
    player["materials"] += int(enemy_value)
    print(str(player["money"]) + " money in balance. " + str(player["materials"]) + " details in inventory.\nPress enter to continue")
    with open(nickname + ".txt", 'w') as new_stats:
        for key in player:
            new_stats.write(str(player[key]) + " ")
elif fight_or_flight == "c":
    player["money"] -= int(10 ** player["level"])
    player["materials"] -= int(5 ** player["level"])
    print("You ran away from battle and lost some materials and money. \nPress enter to continue")
    with open(nickname + ".txt", 'w') as new_stats:
        for key in player:
            new_stats.write(str(player[key]) + " ")
exit(0)