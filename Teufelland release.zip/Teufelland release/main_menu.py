import time
import os

def starting_cutscene(ascii_art, msg):
    animation = ""
    for i in range(len(msg)):
            os.system('cls')
            animation += msg[i]
            print(ascii_art + "\n\n\n")
            print(animation)
            time.sleep(0.03)
    input("Press enter to continue ")

def new_game_cutscene():
        ascii_art = "               #####\n              #######\n  #####################\n#########################\n ########################\n  ######################\n        #############\n         ###      #\n        ##       ####\n       ##         #\n"
        msg = "Long while ago, in the Erlsburg realm, peace was shattered. A portal to the unknown worlds has opened.\nWaves of angry creatures marched in, devastating everything, bringing disaster.\nThe surrounding territories were called Teufelland"
        starting_cutscene(ascii_art, msg)
        msg = "40 years of terror have passed, when the daughter of baron Erich fon Hoffmann - Alexandra was kidnapped. Scouts whisper, she was taken to Hammerlein castle.\nBaron called for help and recruited an unknown mercenary."
        ascii_art = "##########################\n############  ############\n## ########    #######  ##\n#    #######  #######    #\n###   #####    #####   ###\n####    ###    ###    ####\n#####                #####\n#####                #####\n##########################\n"
        starting_cutscene(ascii_art, msg)
        msg = "Territory of Teufelland, marriage with Alexandra and a hundred pounds of gold were promised to the hireling named " + nickname + " by the king of Erlsburg Herman II and baron Erich."
        starting_cutscene(ascii_art, msg)
        ascii_art = "            #            \n  #        ###        #  \n ###      ## ##      ### \n#####    #######    #####\n## ##    ### ###    ## ##\n## ## # #### #### # ## ##\n#########################\n#########################\n## ########   ######## ##\n## #######     ####### ##\n##########     ##########\n"
        msg = nickname + " was a man of honor. \"There is no going back from there, turn around\", \"Fool! You'll die there. \" he was told. But he knew where he was going. From here, begins your journey. "
        starting_cutscene(ascii_art, msg)
        os.system("cls")

print("                        :##         ###    ###                      #\n#######                 #.            #      #                      #\n   #                    #             #      #                      #")
print("   #     ###   #   #  #####   ###     #      #    .###.  #:##:   ## #\n   #    #   #  #   #    #    #   #    #      #    #: :#  #  :#  #   #\n   #    #   #  #   #    #    #   #    #      #        #  #   #  #   #")
print("   #    #####  #   #    #    #####    #      #    :####  #   #  #   #\n   #    #      #:  #    #    #        #.     #.   #.  #  #   #  #   #\n   #     ###:  :##:#    #     ###     :##    :##  :##:#  #   #   ## #\n\n\n\n")
print("Teufelland dev build v. 0.2.2 \nPress enter to start ")
input()

while (True):
    main_menu_choice = int(input("1 - load game\n2 - new game\n3 - credits\n0 - exit\n"))

    if main_menu_choice == 1:
        nickname = str(input("Enter nickname: "))
        with open(nickname + ".txt", 'r') as load_player:
            player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
            file_content = load_player.read().split()
            arr_count = 0
            for key in player:
                player[key] = int(file_content[arr_count])
                arr_count+=1
            print(player)
        with open("temp.txt", 'w') as transit_vars:
            transit_vars.write(nickname)
        exit(0)
        

    if main_menu_choice == 2:
        nickname = str(input("Enter nickname: "))
        skip_cutscene = str(input("Would you like to skip the cutscene?(yes/no) "))
        if skip_cutscene == "no":
            new_game_cutscene()
        with open(nickname + ".txt", 'w') as new_player:
            player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
            for key in player:
                new_player.write(str(player[key]) + " ")
        with open("temp.txt", 'w') as transit_vars:
            transit_vars.write(nickname)
        print(nickname + ":\n" + str(player))
        exit (0)

    if main_menu_choice == 3:
        print("Game made by Magzhan Uderbay and Artemyi Poberezhnyi\nas a group project for informatics class")

    if main_menu_choice == 0:
        exit(1)
