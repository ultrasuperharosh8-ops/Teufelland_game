import os
import time

def cutscene(ascii_art, msg):
    animation = ""
    for i in range(len(msg)):
            os.system('cls')
            animation += msg[i]
            print(ascii_art + "\n\n\n")
            print(animation)
            time.sleep(0.03)
    input("Press enter to continue ")
ascii_art = ("      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # >   < #   #  \n   #  #   #   #   #  \n  #    #  M  #     # \n #       # #        #\n #       # #        #\n")
msg = "Step away! Don't touch me, please! "
cutscene(ascii_art, msg)
ascii_art = "      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # >   o #   #  \n   #  #   #   #   #  \n  #    #  _  #     # \n #       # #        #\n #       # #        #\n"
msg = "... wh- who are you?"
cutscene(ascii_art, msg)
ascii_art="      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # >   < #   #  \n   #  #   # , #   #  \n  #    #  o  #     # \n #       # #        #\n #       # #        #\n"
msg = "Have you been sent by my father? Please, get me out of here! These-... These monsters were going to kill me! Please!"
cutscene(ascii_art, msg)
ascii_art="      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # o   o #   #  \n   #  #   #   #   #  \n  #    #  *  #     # \n #       # #        #\n #       # #        #\n"
msg = "You (whispering): Be quiet! I was sent by your father and will get us out of here. Follow me!"
cutscene(ascii_art, msg)
ascii_art = "\n\n\n\n\n\n\n\n\n\n\n\n"
msg = "You have picked up Alexandra. Head towards the portal and leave the castle!"
cutscene(ascii_art, msg)