import random
import time
player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
#getting player's nickname
with open("temp.txt", 'r') as transit_vars:
    nickname = transit_vars.read()
print(nickname + ":")


#getting player's stats
with open(nickname + ".txt", 'r') as load_player:
    file_content = load_player.read().split()
    arr_count = 0
    for key in player:
          player[key] = int(file_content[arr_count])
          arr_count+=1
print(player)


temp = ["weapon", "money", "materials", "HP"]
loot_type = random.choice(temp)
print("Congrats! You found a chest with loot. Let's see what we've got here...")
time.sleep(3)
print("You are recieving " + loot_type + " in amount of...")
for x in range(10):
    loot_amount = random.randint(10, 100)
    print(loot_amount)
    time.sleep(0.2)
print("You've recieved " + loot_type + " in amount of " + str(loot_amount) + "!")
player[loot_type]+=int(loot_amount)
with open(nickname + ".txt", 'w') as update_player_data:
            for key in player:
                update_player_data.write(str(player[key]) + " ")
exit(0)