import time
import random
import os
def cutscene(ascii_art, msg):
    animation = ""
    for i in range(len(msg)):
            os.system('cls')
            animation += msg[i]
            print(ascii_art + "\n\n\n")
            print(animation)
            time.sleep(0.03)
    input("Press enter to continue ")
player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
#getting player's nickname
with open("temp.txt", 'r') as transit_vars:
    nickname = transit_vars.read()
print(nickname + ":")


#getting player's stats
with open(nickname + ".txt", 'r') as load_player:
    file_content = load_player.read().split()
    arr_count = 0
    for key in player:
          player[key] = int(file_content[arr_count])
          arr_count+=1

boss_hp = 1000
boss_dmg = 100
player_hp = player["HP"]
skip_cutscene = str(input("Would you like to skip the cutscene?(yes/no) "))
#cutscene
if skip_cutscene == "no":
    art = "   ####     ####   \n  # #  #   #  # #  \n  #  #       #  #  \n   #  #_____#  #   \n   ####     ####   \n  #  _   #   _  #  \n  #   \\     /   #  \n   # O  ###  O #   \n   #     #     #   \n    #   ___   #    \n     # /|||\\ #     \n #### ####### #### \n#     #######     #\n#     # # # #     #\n#     # # # #     #\n"
    msg = "Is that you, mortal, who dares to step into my domain?\nHow astonishingly bald... or foolish... you must be to step into this castle."
    cutscene(art, msg)
    msg = "I am Malum Inevitablis - the inevitable doom. Not a single soul survived after a fight with me."
    cutscene(art, msg)
    msg = "You know... you are the first intruder worthy enough for me to face myself.\nMy warriors fell before you - impressive. For a human."
    cutscene(art, msg)
    msg = "And yet... I will grant you something no mortal ever received: \na chance to flee. Turn back. Live a few more worthless years."
    cutscene(art, msg)
    art = "      #   #   #      \n      #___#___#      \n       #     #       \n      #########      \n     ##   __  ###    \n    #  ###  ##   #   \n   #  #       #   #  \n   #  # O   o #   #  \n   #  #   #   #   #  \n  #    #  _  #     # \n #       # #        #\n #       # #        #\n"
    msg = "..."
    cutscene(art, msg)
    art = "   ####     ####   \n  # #  #   #  # #  \n  #  #       #  #  \n   #  #_____#  #   \n   ####     ####   \n  #  _   #   _  #  \n  #   \\     /   #  \n   # O  ###  O #   \n   #     #     #   \n    #   ___   #    \n     # /|||\\ #     \n #### ####### #### \n#     #######     #\n#     # # # #     #\n#     # # # #     #\n"
    msg = "Oh... the girl... So this is why you wandered so far into death itself.\nI will not let her escape. Not now. Not ever.\nToo bad for you, mortal. Your courage ends here. This battle shall be short..."
    cutscene(art, msg)
    msg = "Prepare to die"
    cutscene(art, msg)

#the battle. Phase 1 - destroing stamps
print("Alexandra: Here! there are some stamps over there!\nStamps make him immortal. Destroy them!")
print("to destroy a stamp, solve a problem as fast as possible!")
time.sleep(3)
for x in range(5):
    start = int(time.time())
    multipl1 = random.randint(2, 50)
    multipl2 = random.randint(2, 50)
    answer = int(input(str(multipl1) + " X " + str(multipl2) + " = "))
    if answer == multipl1 * multipl2:
        finish = int(time.time())
        print("Correct! Stamp " + str(x+1) + " destroyed")
        print("Malum Inavitablis dealed you " + str((finish - start) * 5) + " HP!")
        player_hp -= (finish - start) * 10 + 20
    else:
        print("Incorrect! Malum Inavitablis dealt you 100 damage!")
        player_hp -= boss_dmg
        x -= 1
        continue


#phase 2
player_hp = player["HP"]
print("Alexandra: Stamps destroyed! Let's now end this!")
time.sleep(2)
print("Malum Inavitablis: Fool! You... Won't defeat ME!")
time.sleep(3)
while(True):
    print("Malum's attack: " + str(boss_dmg - 0.5 * player["armor"]))
    player_hp -= boss_dmg - 0.5 * player["armor"]
    print("Your HP remaining: " + str(player_hp))
    time.sleep(2)
    print("Your attack: " + str(player["weapon"]))
    boss_hp -= player["weapon"]
    time.sleep(2)
    print("Alexandra's attack: 5")
    boss_hp -= 5
    print("Boss HP remaining: " + str(boss_hp))
    time.sleep(2)
    if player_hp <= 0:
        print("You lost! Game over. ")
        exit(2)
    if boss_hp <= 0:
        print("Boss defeated!")
        break


#final cutscene
art = "   ####     ####   \n  # #  #   #  # #  \n  #  #       #  #  \n   #  #_____#  #   \n   ####     ####   \n  #  _ --#   _  #  \n  # /         \\ #  \n   # O  ###  * #   \n   #     #  *  #   \n    # * ___   #    \n     #  |||  #     \n #### ####### #### \n#     #######    ##\n#     # # # #   #  \n#     # # # #  #  #\n"
msg = "Ah, mortal. Should I knew this day shall come. Should I knew I'll be defeated one day."
cutscene(art, msg)
choice = 0
fourthoption = ""
while(choice != 3):
    print("1 - Who and why opened the portal?\n2 - Why have you kidnapped Alexandra?\n3 - I need you to close the portal! " + fourthoption)
    choice = int(input())
    if choice == 1:
        msg = "Portal is a deed of mine. Our land has degradated, resources ended. A famine has started.\nWe needed new lands and food sources, so I opened the portal"
        cutscene(art, msg)
    if choice == 2:
        msg = "Alexandra is from the Hoffmann house. The portal was too weak, and we needed Hoffmann female blood.\nHoffmanns is an ancient house, which unified with our species before the Great Rift\nHer blood is unique. It could strengthen the portal so much, you, humans would be extinct"
        cutscene(art, msg)
        fourthoption = "\nthe Great Rift? "
    if choice == 3:
        msg = "If it's destinated, I'll take responsebility for our extinction.\nBut I will ask you ONE question.\nWhat was YOUR motive? "
        cutscene(art, msg)
        break
    if choice == 4:
        art = "  #     #         _:##\n /#\\ # /#\\  #    :###:\n / \\/#\\/ \\ /#\\ _:###: \n    / \\    / \\:####: ?\n #          ####:-? ? \n/#\\      _:####: ? ? ?\n/ \\    :####:-? ? ? ? \n    ._####:? ? ? ? ? ?\n___:###:? ? ? ? ? ? ? \n#####: ? ? ? ? ? ? ? ?\n"
        msg = "ahh, mortal. Even your ancestors were too young to witness the Great Rift.\nYour and our species could not live peacefully in one world. Wars, pillages, killings.\nIt was so cruel, God itself interrupted and divided our worlds. We are here to revenge for our fathers"
        cutscene(art, msg)
        art = "   ####     ####   \n  # #  #   #  # #  \n  #  #       #  #  \n   #  #_____#  #   \n   ####     ####   \n  #  _ --#   _  #  \n  # /         \\ #  \n   # O  ###  * #   \n   #     #  *  #   \n    # * ___   #    \n     #  |||  #     \n #### ####### #### \n#     #######    ##\n#     # # # #   #  \n#     # # # #  #  #\n"
choice = int(input("1 - Money and land.\n2 - love for Alexandra\n3 - to protect the people of Teufelland "))
art = "     ##########     \n  ### _______  ###  \n #   / ____  \\    #\n#   | / .__| |     #\n#   | |______/     #\n #   --      .    # \n  ###  ------  ###  \n     ##########     \n"
if choice == 1:
    msg = "You people were always greedy about your money and income.\nWilling to doom other entire species for death, just for the money.\nNever doubted it.\n"
if choice == 2:
    msg = "Love... An interesting feeling of your kind.\nWhen you can sacrifice yourself in the name of her. When you have someone to live for.\nI respect your motive"
if choice == 3:
    msg = "I understand your opinion. I fought for my kind, you fought for your kind. And you won."
cutscene(art, msg)
art = "     ##########     \n  ###          ###  \n #                # \n#                  #\n#                  #\n #                # \n  ###          ###  \n     ##########     \n"
msg = "The portal is closed."
cutscene(art, msg)