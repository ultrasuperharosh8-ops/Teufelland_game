player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
#getting player's nickname
with open("temp.txt", 'r') as transit_vars:
    nickname = transit_vars.read()
print(nickname + ":")


#getting player's stats
with open(nickname + ".txt", 'r') as load_player:
    file_content = load_player.read().split()
    arr_count = 0
    for key in player:
          player[key] = int(file_content[arr_count])
          arr_count+=1
print(player)
print("You've stepped into a trap! 50 coins are lost! ")
player["money"]-=50
with open(nickname + ".txt", 'w') as update_player_data:
            for key in player:
                update_player_data.write(str(player[key]) + " ")
print("Press enter to quit ")
exit(0)