import time
import os
player = {"weapon":8, "HP":40, "money":0, "armor":0, "materials":0, "level":1}
with open("temp.txt", 'r') as transit_vars:
    nickname = transit_vars.read()
print(nickname + ":")

with open(nickname + ".txt", 'r') as load_player:
    file_content = load_player.read().split()
    arr_count = 0
    for key in player:
          player[key] = int(file_content[arr_count])
          arr_count+=1
print(player)

choice = int(input("Menu: 1 - shopping menu, 2 - crafting menu, 3 - leave to main menu, 0 - return to map. "))

if choice == 1:
    weapon_for_sale = [10, 15, 25, 40, 100]
    armor_for_sale = [2, 5, 10, 25, 50]
    hp_for_sale = [50, 75, 100, 150, 200]
    print("\n\n\n\n" + "   #  \n  ### \n # # #\n # #  \n  ##  \n   ## \n   # #\n   # #\n #### \n   #  \n   #  \n" + "\n\n\n\n")
    while(True):
        
        choice2 = int(input("Welcome to the shop. What would you like to buy? \n1 - weapon, 2 - armor, 3 - health poisons, 4 - details, 0 - quit shopping. "))
        if choice2 == 1:
            print("Weapon? We have a widest weapons assortiment here in Teufelland! Let me see what can I offer to you... ")
            time.sleep(4)
            choice3 = int(input("1 - 10dmg sword: 20\n2 - 15dmg sword: 45\n3 - 25dmg sword: 125\n4 - 40dmg sword - a weapon for really serious cases: 320\n5 - 100dmg sword - mein wunderwaffe:2 000\n0 - cancel "))
            if choice3 == 0:
                continue
            cost = (weapon_for_sale[choice3 - 1] ** 2) / 5
            if player["money"] < cost:
                print("not enough money! ")
                continue
            player["weapon"] += weapon_for_sale[choice3 - 1]
        elif choice2 == 2:
            print("Armor? Best in ze welt, freunde! Let's see what we have here... ")
            time.sleep(4)
            choice3 = int(input("1 - 2 armor: 10\n2 - 5 armor: 25\n3 - 10 armor: 50\n4 - 25 armor - very heavy!: 125\n5 - 50 armor - real panzer!: 250\n0 - quit "))
            if choice3 == 0:
                continue
            cost = armor_for_sale[choice3-1] * 5
            if player["money"] < cost:
                print("not enough money! ")
                continue
            player["armor"] += armor_for_sale[choice3-1]
        elif choice2 == 3:
            print("Ja, freunde, I have some poisons for you. Ein moment... ")
            time.sleep(4)
            choice3 = int(input("1 - 50 HP: 100\n2 - 75 HP: 150\n3 - 100 HP: 200\n4 - 150 HP - can't kill you: 300\n5 - 200 HP - UBERMACHINE!: 400\n0 - quit "))
            if choice3 == 0:
                continue
            cost = (hp_for_sale[choice3-1] * 2)
            if player["money"] < cost:
                print("not enough money! ")
                continue
            player["HP"] += hp_for_sale[choice3-1]
        elif choice2 == 4:
            print("Details fur krafting? Problem kein, just let me take a look at this box... ")
            time.sleep(4)
            choice3 = int(input("Could you remind me, how many of these do you need? "))
            cost = choice3 * 10
            if player["money"] < cost:
                print("not enough money! ")
                continue
            player["materials"] += choice3
        elif choice2 == 0:
            print("Tschuss!")
            print("Press enter to quit ")
            cost = 0
            break
        player["money"] -= int(cost)
elif choice == 2:
    weapon_for_craft = [12, 20, 32, 50, 200]
    armor_for_craft = [7, 15, 60, 100]
    hp_for_craft = [50, 80, 120, 180, 250, 300]
    print("\n\n\n\n" + "##########  \n#         # \n#####  ##  #\n    #  #  # \n    #  #    \n    #  #    \n    #  #    \n    ####    \n" + "\n\n\n\n")
    while(True):
        buying_stuff = ""
        bought_amount = 0
        choice2 = int(input("Crafting: 1 - weapons, 2 - armor, 3 - hp, 0 - quit"))
        if choice2 == 1:
            print("0 - cancel")
            for i in range(len(weapon_for_craft)):
                print(str(i + 1) + ". - " + str(weapon_for_craft[i]) + " crafted with " + str(weapon_for_craft[i] * 1.5) + " details")
            choice3 = int(input())
            if choice3 == 0:
                continue
            cost = int(weapon_for_craft[choice3-1] * 1.5)
            buying_stuff = "weapon"
            bought_amount = weapon_for_craft[choice3-1]
        elif choice2 == 2:
            print("0 - cancel")
            for i in range(len(armor_for_craft)):
                print(str(i+1) + ". - " + str(armor_for_craft[i]) + " crafted with " + str(armor_for_craft[i] * 3) + " details")
            choice3 = int(input())
            if choice3 == 0:
                continue
            cost = int(armor_for_craft[choice3-1] * 3)
            buying_stuff = "armor"
            bought_amount = armor_for_craft[choice3-1]
        elif choice2 == 3:
            print("0 - cancel")
            for i in range(len(hp_for_craft)):
                print(str(i+1) + ". - " + str(hp_for_craft[i]) + " crafted with " + str(hp_for_craft[i]) + " details")
            choice3 = int(input())
            if choice3 == 0:
                continue
            cost = int(hp_for_craft[choice3-1])
            buying_stuff = "HP"
            bought_amount = hp_for_craft[choice3-1]
        elif choice2 == 0: #fucking rusophobs. There was a russian commentary, and python gave me an error because of non-UTF8 COMMENTARY. Suka blyat 
            print("Press enter to quit ")
            break
        if player["materials"] < cost:
            print("not enough details!")
            continue
        player["materials"] -= int(cost)
        player[buying_stuff] += int(bought_amount)
if choice == 3:
    os.system("python main_menu.py")
if choice == 0:
    print("Press enter to quit ")
    exit(0)
with open(nickname + ".txt", 'w') as update_player_data:
            for key in player:
                update_player_data.write(str(player[key]) + " ")
